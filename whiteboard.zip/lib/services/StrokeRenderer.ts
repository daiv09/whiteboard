/**
 * StrokeRenderer.ts
 * Calligraphy vector graphics synthesizer & requestAnimationFrame timed-playback animation engine.
 */

export interface Point {
  x: number;
  y: number;
  pressure?: number;
  t?: number; // relative time delta in ms from stroke start
}

export interface Stroke {
  points: Point[];
  color: string;
  width: number;
}

/**
 * PrimeRequest represents the handwriting LSTM priming shape payload.
 */
export interface PrimeRequest {
  priming_strokes: {
    char: string;
    strokes: Point[][];
  }[];
  text: string;
  bias: number; // controls handwriting style variation/jitter
}

/**
 * Fits a Catmull-Rom spline through control points and converts to cubic Bezier curves
 */
export function fitCatmullRomToCubicBezier(
  points: Point[],
  tension: number = 0.5
): { p0: Point; cp1: Point; cp2: Point; p1: Point }[] {
  if (points.length < 4) return [];

  const curves = [];
  for (let i = 1; i < points.length - 2; i++) {
    const p0 = points[i - 1];
    const p1 = points[i];
    const p2 = points[i + 1];
    const p3 = points[i + 2];

    // Compute cubic Bezier control points from Catmull-Rom control points
    const cp1x = p1.x + ((p2.x - p0.x) / 6) * tension;
    const cp1y = p1.y + ((p2.y - p0.y) / 6) * tension;

    const cp2x = p2.x - ((p3.x - p1.x) / 6) * tension;
    const cp2y = p2.y - ((p3.y - p1.y) / 6) * tension;

    curves.push({
      p0: p1,
      cp1: { x: cp1x, y: cp1y, pressure: p1.pressure },
      cp2: { x: cp2x, y: cp2y, pressure: p2.pressure },
      p1: p2
    });
  }

  return curves;
}

/**
 * StrokeRenderer handles real-time handwriting drawing animations at a human pace
 */
export class StrokeRenderer {
  private activeAnimationId: number | null = null;

  /**
   * Replays a list of calligraphic strokes progressively on a canvas context
   */
  public animate(
    ctx: CanvasRenderingContext2D,
    strokes: Stroke[],
    speedMultiplier: number = 1.0,
    onFrame: () => void,
    onComplete?: () => void
  ) {
    this.cancel();

    if (strokes.length === 0) {
      if (onComplete) onComplete();
      return;
    }

    const totalDuration = strokes.reduce((acc, stroke) => {
      if (stroke.points.length === 0) return acc;
      const lastPoint = stroke.points[stroke.points.length - 1];
      return acc + (lastPoint.t || 0);
    }, 0);

    const startTime = performance.now();

    const drawFrame = (now: number) => {
      const elapsed = (now - startTime) * speedMultiplier;
      
      // Clear screen frame boundary
      onFrame();

      let currentAccumTime = 0;
      let animationFinished = true;

      // Render each stroke up to the elapsed timestamp limit
      strokes.forEach((stroke) => {
        const points = stroke.points;
        if (points.length === 0) return;

        const renderedPoints: Point[] = [];
        for (let i = 0; i < points.length; i++) {
          const pt = points[i];
          const pointTime = pt.t || 0;
          
          if (elapsed >= currentAccumTime + pointTime) {
            renderedPoints.push(pt);
          } else {
            animationFinished = false;
            break;
          }
        }

        if (renderedPoints.length > 0) {
          this.drawCalligraphicStroke(ctx, renderedPoints, stroke.color, stroke.width);
        }

        const lastPt = points[points.length - 1];
        currentAccumTime += lastPt.t || 0;
      });

      if (!animationFinished) {
        this.activeAnimationId = requestAnimationFrame(drawFrame);
      } else {
        this.activeAnimationId = null;
        if (onComplete) onComplete();
      }
    };

    this.activeAnimationId = requestAnimationFrame(drawFrame);
  }

  /**
   * Cancels active requestAnimationFrame loop
   */
  public cancel() {
    if (this.activeAnimationId !== null) {
      cancelAnimationFrame(this.activeAnimationId);
      this.activeAnimationId = null;
    }
  }

  /**
   * Renders smooth cubic Bezier segments with calligraphic pressure variations
   */
  private drawCalligraphicStroke(
    ctx: CanvasRenderingContext2D,
    points: Point[],
    color: string,
    brushWidth: number
  ) {
    if (points.length === 0) return;
    if (points.length < 4) {
      // Fallback to simple line segments if too few points for Catmull-Rom
      ctx.beginPath();
      ctx.strokeStyle = color;
      ctx.lineCap = "round";
      ctx.lineJoin = "round";
      ctx.moveTo(points[0].x, points[0].y);

      for (let i = 1; i < points.length; i++) {
        const p1 = points[i - 1];
        const p2 = points[i];
        const pressure = p2.pressure !== undefined ? p2.pressure : 0.6;
        ctx.lineWidth = brushWidth * pressure;
        ctx.lineTo(p2.x, p2.y);
      }
      ctx.stroke();
      return;
    }

    ctx.lineCap = "round";
    ctx.lineJoin = "round";
    ctx.strokeStyle = color;

    // Convert and draw cubic Bezier curves
    const curves = fitCatmullRomToCubicBezier(points);
    curves.forEach((curve) => {
      ctx.beginPath();
      const avgPressure = ((curve.cp1.pressure || 0.6) + (curve.cp2.pressure || 0.6)) / 2;
      ctx.lineWidth = brushWidth * avgPressure;
      
      ctx.moveTo(curve.p0.x, curve.p0.y);
      ctx.bezierCurveTo(
        curve.cp1.x,
        curve.cp1.y,
        curve.cp2.x,
        curve.cp2.y,
        curve.p1.x,
        curve.p1.y
      );
      ctx.stroke();
    });
  }

  /**
   * Prepares and posts a priming payload to the local offline synthesis API endpoint
   */
  public static async requestSynthesis(
    text: string,
    profile: Record<string, Point[][]>,
    endpoint: string = "http://localhost:5000/synthesize"
  ): Promise<Point[][]> {
    const primingStrokes = Object.keys(profile).map((char) => ({
      char,
      strokes: profile[char]
    }));

    const payload: PrimeRequest = {
      priming_strokes: primingStrokes,
      text,
      bias: 0.75
    };

    const response = await fetch(endpoint, {
      method: "POST",
      headers: {
        "Content-Type": "application/json"
      },
      body: JSON.stringify(payload)
    });

    if (!response.ok) {
      throw new Error(`Synthesis server responded with status: ${response.status}`);
    }

    const data = await response.json();
    return data.strokes; // Returns Point[][] arrays representing synthesized shapes
  }
}
